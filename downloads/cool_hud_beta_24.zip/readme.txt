Thanks for Downloading my HUD!

To install just drag the "Cool Hud Beta 2.4" folder into your custom tf2 folder,
by default located here:
"C:\Program Files (x86)\Steam\steamapps\common\Team Fortress 2\tf\custom"

To install any addon is the same thing, just drag the fodler with the "#" at the same place.